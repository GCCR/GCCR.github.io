---
author: cbouysset
title: Our COVID-19 survey is now online
---

Welcome to our brand new news section !

The COVID-19 survey is now available in English through the following link: [http://bit.ly/343fERK](http://bit.ly/343fERK)

Translated versions will follow very soon.